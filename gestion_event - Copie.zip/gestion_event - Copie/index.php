<?php
   
    if (!isset($_SESSION['username']))
    {
        include 'login.php';
        die();
    }
?>